package dao;

import beans.Categoria;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CategoriaDAO {
    Conexao conexao;
    Connection conn;

    public CategoriaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    public boolean inserir(Categoria categoria){
        String sql = "INSERT INTO categorias (nome) VALUES (?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, categoria.getNome());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir categoria: "+ex.getMessage());
            return false;
        }
    }

    public boolean editar(Categoria categoria){
        try {
            String sql = "UPDATE categorias set nome=? WHERE id=?";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, categoria.getNome());
            stmt.setInt(2, categoria.getId());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar categoria: "+ex.getMessage());
            return false;
        }
    }

    public boolean excluir(int id){
        try {
            String sql = "delete from categorias WHERE id=?";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir categoria: "+ex.getMessage());
            return false;
        }
    }

    public ArrayList<Categoria> listar(){
        ArrayList<Categoria> lista = new ArrayList<>();
        String sql = "SELECT * FROM categorias ORDER BY nome";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Categoria c = new Categoria();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                lista.add(c);
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao listar categorias: "+ex.getMessage());
        }
        return lista;
    }
}
