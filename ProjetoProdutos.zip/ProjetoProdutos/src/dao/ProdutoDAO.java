package dao;

import beans.Produto;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProdutoDAO {
    Conexao conexao;
    Connection conn;
    String selectBase = "SELECT p.id, p.nome, p.preco, p.quantidade, p.categoria_id, "
            + "c.nome AS categoria_nome FROM produtos p "
            + "INNER JOIN categorias c ON c.id = p.categoria_id ";

    public ProdutoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    Produto montar(ResultSet rs) throws SQLException {
        Produto p = new Produto();
        p.setId(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setPreco(rs.getDouble("preco"));
        p.setQuantidade(rs.getInt("quantidade"));
        p.setCategoriaId(rs.getInt("categoria_id"));
        p.setCategoriaNome(rs.getString("categoria_nome"));
        return p;
    }

    public boolean inserir(Produto produto){
        String sql = "INSERT INTO produtos (nome, preco, quantidade, categoria_id) VALUES (?,?,?,?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoriaId());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir produto: "+ex.getMessage());
            return false;
        }
    }

    public Produto getProduto(int id){
        String sql = selectBase + "WHERE p.id = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                return montar(rs);
            }
            return null;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar produto: "+ex.getMessage());
            return null;
        }
    }

    public boolean editar(Produto produto){
        try {
            String sql = "UPDATE produtos set nome=?, preco=?, quantidade=?, categoria_id=? WHERE id=?";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoriaId());
            stmt.setInt(5, produto.getId());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar produto: "+ex.getMessage());
            return false;
        }
    }

    public boolean excluir(int id){
        try {
            String sql = "delete from produtos WHERE id=?";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir produto: "+ex.getMessage());
            return false;
        }
    }

    public ArrayList<Produto> listar(){
        ArrayList<Produto> lista = new ArrayList<>();
        String sql = selectBase + "ORDER BY p.nome";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                lista.add(montar(rs));
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao listar produtos: "+ex.getMessage());
        }
        return lista;
    }

    public ArrayList<Produto> buscarPorNome(String nome){
        ArrayList<Produto> lista = new ArrayList<>();
        String sql = selectBase + "WHERE p.nome LIKE ? ORDER BY p.nome";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                lista.add(montar(rs));
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao buscar produtos: "+ex.getMessage());
        }
        return lista;
    }

    public ArrayList<Produto> buscarPorCategoria(String categoria){
        ArrayList<Produto> lista = new ArrayList<>();
        String sql = selectBase + "WHERE c.nome LIKE ? ORDER BY p.nome";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + categoria + "%");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                lista.add(montar(rs));
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao buscar produtos: "+ex.getMessage());
        }
        return lista;
    }
}
