package telas;



public class MenuPrincipal extends javax.swing.JFrame {



    public MenuPrincipal() {
        initComponents();
        setSize(320, 140);
        setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_Titulo = new javax.swing.JLabel();
        pnl_Botoes = new javax.swing.JPanel();
        btn_Produtos = new javax.swing.JButton();
        btn_Categorias = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Controle de Produtos");

        lbl_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_Titulo.setText("Controle de Produtos");
        getContentPane().add(lbl_Titulo, java.awt.BorderLayout.NORTH);

        btn_Produtos.setText("Produtos");
        btn_Produtos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ProdutosActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Produtos);

        btn_Categorias.setText("Categorias");
        btn_Categorias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CategoriasActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Categorias);

        getContentPane().add(pnl_Botoes, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ProdutosActionPerformed
        new TelaProdutos().setVisible(true);
    }//GEN-LAST:event_btn_ProdutosActionPerformed

    private void btn_CategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CategoriasActionPerformed
        new TelaCategorias().setVisible(true);
    }//GEN-LAST:event_btn_CategoriasActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    javax.swing.JLabel lbl_Titulo;
    javax.swing.JPanel pnl_Botoes;
    javax.swing.JButton btn_Produtos;
    javax.swing.JButton btn_Categorias;
    // End of variables declaration//GEN-END:variables
}
