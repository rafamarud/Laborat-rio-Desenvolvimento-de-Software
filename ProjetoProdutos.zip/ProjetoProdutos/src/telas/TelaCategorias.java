package telas;

import beans.Categoria;
import dao.CategoriaDAO;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaCategorias extends javax.swing.JFrame {

    DefaultTableModel modelo;
    CategoriaDAO cDAO = new CategoriaDAO();

    public TelaCategorias() {
        initComponents();
        modelo = (DefaultTableModel) tbl_Categorias.getModel();
        setSize(450, 400);
        setLocationRelativeTo(null);
        listarCategorias();
    }

    void listarCategorias(){
        modelo.setRowCount(0);
        for(Categoria c : cDAO.listar()){
            modelo.addRow(new Object[]{c.getId(), c.getNome()});
        }
    }

    private void limparFormulario() {
        txt_ID.setText("");
        txt_Nome.setText("");
        tbl_Categorias.clearSelection();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        java.awt.GridBagConstraints gridBagConstraints;

        pnl_Topo = new javax.swing.JPanel();
        pnl_Dados = new javax.swing.JPanel();
        lbl_ID = new javax.swing.JLabel();
        txt_ID = new javax.swing.JTextField();
        lbl_Nome = new javax.swing.JLabel();
        txt_Nome = new javax.swing.JTextField();
        pnl_Botoes = new javax.swing.JPanel();
        btn_Salvar = new javax.swing.JButton();
        btn_Atualizar = new javax.swing.JButton();
        btn_Excluir = new javax.swing.JButton();
        btn_Limpar = new javax.swing.JButton();
        scr_Categorias = new javax.swing.JScrollPane();
        tbl_Categorias = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Categorias");

        pnl_Topo.setLayout(new java.awt.BorderLayout());
        pnl_Dados.setLayout(new java.awt.GridBagLayout());
        lbl_ID.setText("ID:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(lbl_ID, gridBagConstraints);

        txt_ID.setEditable(false);
        txt_ID.setColumns(6);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(txt_ID, gridBagConstraints);

        lbl_Nome.setText("Nome:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(lbl_Nome, gridBagConstraints);

        txt_Nome.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(txt_Nome, gridBagConstraints);

        pnl_Topo.add(pnl_Dados, java.awt.BorderLayout.NORTH);

        pnl_Botoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        btn_Salvar.setText("Salvar");
        btn_Salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SalvarActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Salvar);

        btn_Atualizar.setText("Atualizar");
        btn_Atualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_AtualizarActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Atualizar);

        btn_Excluir.setText("Excluir");
        btn_Excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ExcluirActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Excluir);

        btn_Limpar.setText("Limpar");
        btn_Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LimparActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Limpar);

        pnl_Topo.add(pnl_Botoes, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnl_Topo, java.awt.BorderLayout.NORTH);

        tbl_Categorias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Categorias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_CategoriasMouseClicked(evt);
            }
        });

        scr_Categorias.setViewportView(tbl_Categorias);
        getContentPane().add(scr_Categorias, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_SalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SalvarActionPerformed
        if(txt_Nome.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(this, "Informe o nome da categoria!");
            return;
        }
        Categoria c = new Categoria();
        c.setNome(txt_Nome.getText().trim());

        if(cDAO.inserir(c)){
            limparFormulario();
            listarCategorias();
        }
        else{
            JOptionPane.showMessageDialog(this, "Erro ao salvar categoria!");
        }
    }//GEN-LAST:event_btn_SalvarActionPerformed

    private void btn_AtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_AtualizarActionPerformed
        if(txt_ID.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Selecione uma categoria na tabela!");
            return;
        }
        if(txt_Nome.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(this, "Informe o nome da categoria!");
            return;
        }
        Categoria c = new Categoria();
        c.setId(Integer.parseInt(txt_ID.getText()));
        c.setNome(txt_Nome.getText().trim());

        if(cDAO.editar(c)){
            limparFormulario();
            listarCategorias();
        }
        else{
            JOptionPane.showMessageDialog(this, "Erro ao atualizar categoria!");
        }
    }//GEN-LAST:event_btn_AtualizarActionPerformed

    private void btn_ExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ExcluirActionPerformed
        if(txt_ID.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Selecione uma categoria na tabela!");
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir?",
                "Exclusão", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION){
            if(cDAO.excluir(Integer.parseInt(txt_ID.getText()))){
                limparFormulario();
                listarCategorias();
            }
            else{
                JOptionPane.showMessageDialog(this,
                        "Não foi possível excluir. Verifique se existem produtos nesta categoria.");
            }
        }
    }//GEN-LAST:event_btn_ExcluirActionPerformed

    private void btn_LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LimparActionPerformed
        limparFormulario();
    }//GEN-LAST:event_btn_LimparActionPerformed

    private void tbl_CategoriasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_CategoriasMouseClicked
        int linha = tbl_Categorias.getSelectedRow();
        if(linha >= 0){
            txt_ID.setText(modelo.getValueAt(linha, 0).toString());
            txt_Nome.setText(modelo.getValueAt(linha, 1).toString());
        }
    }//GEN-LAST:event_tbl_CategoriasMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    javax.swing.JPanel pnl_Topo;
    javax.swing.JPanel pnl_Dados;
    javax.swing.JLabel lbl_ID;
    javax.swing.JTextField txt_ID;
    javax.swing.JLabel lbl_Nome;
    javax.swing.JTextField txt_Nome;
    javax.swing.JPanel pnl_Botoes;
    javax.swing.JButton btn_Salvar;
    javax.swing.JButton btn_Atualizar;
    javax.swing.JButton btn_Excluir;
    javax.swing.JButton btn_Limpar;
    javax.swing.JScrollPane scr_Categorias;
    javax.swing.JTable tbl_Categorias;
    // End of variables declaration//GEN-END:variables
}
