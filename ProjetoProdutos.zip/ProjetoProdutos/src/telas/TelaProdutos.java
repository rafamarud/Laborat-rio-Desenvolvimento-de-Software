package telas;

import beans.Categoria;
import beans.Produto;
import dao.CategoriaDAO;
import dao.ProdutoDAO;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaProdutos extends javax.swing.JFrame {

    DefaultTableModel modelo;
    ProdutoDAO pDAO = new ProdutoDAO();
    CategoriaDAO cDAO = new CategoriaDAO();

    public TelaProdutos() {
        initComponents();
        modelo = (DefaultTableModel) tbl_Produtos.getModel();
        setSize(760, 560);
        setLocationRelativeTo(null);
        carregarCategorias();
        listarProdutos();
    }

    void carregarCategorias(){
        Categoria atual = (Categoria) cmb_Categoria.getSelectedItem();
        cmb_Categoria.removeAllItems();
        for(Categoria c : cDAO.listar()){
            cmb_Categoria.addItem(c);
            if(atual != null && c.getId() == atual.getId()){
                cmb_Categoria.setSelectedItem(c);
            }
        }
    }

    void selecionarCategoria(int id){
        for(int i = 0; i < cmb_Categoria.getItemCount(); i++){
            if(cmb_Categoria.getItemAt(i).getId() == id){
                cmb_Categoria.setSelectedIndex(i);
                return;
            }
        }
    }

    void preencherTabela(ArrayList<Produto> lista){
        modelo.setRowCount(0);
        for(Produto p : lista){
            modelo.addRow(new Object[]{
                p.getId(),
                p.getNome(),
                String.format("%.2f", p.getPreco()),
                p.getQuantidade(),
                p.getCategoriaNome()
            });
        }
    }

    void listarProdutos(){
        preencherTabela(pDAO.listar());
    }

    void carregarProduto(int id){
        Produto p = pDAO.getProduto(id);
        if(p == null){
            return;
        }
        txt_ID.setText(String.valueOf(p.getId()));
        txt_Nome.setText(p.getNome());
        txt_Preco.setText(String.format("%.2f", p.getPreco()));
        txt_Quantidade.setText(String.valueOf(p.getQuantidade()));
        selecionarCategoria(p.getCategoriaId());
    }

    Produto lerFormulario(){
        String nome = txt_Nome.getText().trim();
        if(nome.isEmpty()){
            JOptionPane.showMessageDialog(this, "Informe o nome do produto!");
            return null;
        }
        Categoria c = (Categoria) cmb_Categoria.getSelectedItem();
        if(c == null){
            JOptionPane.showMessageDialog(this, "Cadastre uma categoria antes de salvar o produto!");
            return null;
        }
        double preco;
        int quantidade;
        try {
            preco = Double.parseDouble(txt_Preco.getText().trim().replace(",", "."));
            quantidade = Integer.parseInt(txt_Quantidade.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Preço e quantidade devem ser números válidos!");
            return null;
        }
        if(preco < 0 || quantidade < 0){
            JOptionPane.showMessageDialog(this, "Preço e quantidade não podem ser negativos!");
            return null;
        }
        Produto p = new Produto();
        p.setNome(nome);
        p.setPreco(preco);
        p.setQuantidade(quantidade);
        p.setCategoriaId(c.getId());
        return p;
    }

    private void limparFormulario() {
        txt_ID.setText("");
        txt_Nome.setText("");
        txt_Preco.setText("");
        txt_Quantidade.setText("");
        cmb_Categoria.setSelectedIndex(cmb_Categoria.getItemCount() > 0 ? 0 : -1);
        tbl_Produtos.clearSelection();
    }

    void buscar(){
        String termo = txt_Busca.getText().trim();
        ArrayList<Produto> lista;
        if("Nome".equals(cmb_TipoBusca.getSelectedItem())){
            lista = pDAO.buscarPorNome(termo);
        }
        else{
            lista = pDAO.buscarPorCategoria(termo);
        }
        preencherTabela(lista);
        if(lista.isEmpty()){
            JOptionPane.showMessageDialog(this, "Nenhum produto encontrado!");
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        java.awt.GridBagConstraints gridBagConstraints;

        pnl_Topo = new javax.swing.JPanel();
        pnl_Dados = new javax.swing.JPanel();
        lbl_ID = new javax.swing.JLabel();
        txt_ID = new javax.swing.JTextField();
        lbl_Nome = new javax.swing.JLabel();
        txt_Nome = new javax.swing.JTextField();
        lbl_Preco = new javax.swing.JLabel();
        txt_Preco = new javax.swing.JTextField();
        lbl_Quantidade = new javax.swing.JLabel();
        txt_Quantidade = new javax.swing.JTextField();
        lbl_Categoria = new javax.swing.JLabel();
        cmb_Categoria = new javax.swing.JComboBox<>();
        pnl_Botoes = new javax.swing.JPanel();
        btn_Salvar = new javax.swing.JButton();
        btn_Atualizar = new javax.swing.JButton();
        btn_Excluir = new javax.swing.JButton();
        btn_Limpar = new javax.swing.JButton();
        pnl_Busca = new javax.swing.JPanel();
        lbl_BuscarPor = new javax.swing.JLabel();
        cmb_TipoBusca = new javax.swing.JComboBox<>();
        txt_Busca = new javax.swing.JTextField();
        btn_Buscar = new javax.swing.JButton();
        btn_ListarTodos = new javax.swing.JButton();
        scr_Produtos = new javax.swing.JScrollPane();
        tbl_Produtos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Produtos");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        pnl_Topo.setLayout(new java.awt.BorderLayout());
        pnl_Dados.setLayout(new java.awt.GridBagLayout());
        lbl_ID.setText("ID:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(lbl_ID, gridBagConstraints);

        txt_ID.setEditable(false);
        txt_ID.setColumns(6);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(txt_ID, gridBagConstraints);

        lbl_Nome.setText("Nome:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(lbl_Nome, gridBagConstraints);

        txt_Nome.setColumns(25);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(txt_Nome, gridBagConstraints);

        lbl_Preco.setText("Preço:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(lbl_Preco, gridBagConstraints);

        txt_Preco.setColumns(10);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(txt_Preco, gridBagConstraints);

        lbl_Quantidade.setText("Quantidade:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(lbl_Quantidade, gridBagConstraints);

        txt_Quantidade.setColumns(10);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(txt_Quantidade, gridBagConstraints);

        lbl_Categoria.setText("Categoria:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(lbl_Categoria, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        pnl_Dados.add(cmb_Categoria, gridBagConstraints);

        pnl_Topo.add(pnl_Dados, java.awt.BorderLayout.NORTH);

        pnl_Botoes.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        btn_Salvar.setText("Salvar");
        btn_Salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SalvarActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Salvar);

        btn_Atualizar.setText("Atualizar");
        btn_Atualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_AtualizarActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Atualizar);

        btn_Excluir.setText("Excluir");
        btn_Excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ExcluirActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Excluir);

        btn_Limpar.setText("Limpar");
        btn_Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LimparActionPerformed(evt);
            }
        });
        pnl_Botoes.add(btn_Limpar);

        pnl_Topo.add(pnl_Botoes, java.awt.BorderLayout.CENTER);

        pnl_Busca.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        lbl_BuscarPor.setText("Buscar por:");
        pnl_Busca.add(lbl_BuscarPor);

        cmb_TipoBusca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nome", "Categoria" }));
        pnl_Busca.add(cmb_TipoBusca);

        txt_Busca.setColumns(20);
        txt_Busca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_BuscaActionPerformed(evt);
            }
        });
        pnl_Busca.add(txt_Busca);

        btn_Buscar.setText("Buscar");
        btn_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_BuscarActionPerformed(evt);
            }
        });
        pnl_Busca.add(btn_Buscar);

        btn_ListarTodos.setText("Listar todos");
        btn_ListarTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ListarTodosActionPerformed(evt);
            }
        });
        pnl_Busca.add(btn_ListarTodos);

        pnl_Topo.add(pnl_Busca, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pnl_Topo, java.awt.BorderLayout.NORTH);

        tbl_Produtos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Preço", "Quantidade", "Categoria"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_Produtos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_ProdutosMouseClicked(evt);
            }
        });

        scr_Produtos.setViewportView(tbl_Produtos);
        getContentPane().add(scr_Produtos, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_SalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SalvarActionPerformed
        Produto p = lerFormulario();
        if(p == null){
            return;
        }
        if(pDAO.inserir(p)){
            limparFormulario();
            listarProdutos();
        }
        else{
            JOptionPane.showMessageDialog(this, "Erro ao salvar produto!");
        }
    }//GEN-LAST:event_btn_SalvarActionPerformed

    private void btn_AtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_AtualizarActionPerformed
        if(txt_ID.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Selecione um produto na tabela!");
            return;
        }
        Produto p = lerFormulario();
        if(p == null){
            return;
        }
        p.setId(Integer.parseInt(txt_ID.getText()));
        if(pDAO.editar(p)){
            limparFormulario();
            listarProdutos();
        }
        else{
            JOptionPane.showMessageDialog(this, "Erro ao atualizar produto!");
        }
    }//GEN-LAST:event_btn_AtualizarActionPerformed

    private void btn_ExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ExcluirActionPerformed
        if(txt_ID.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Selecione um produto na tabela!");
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir?",
                "Exclusão", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION){
            if(pDAO.excluir(Integer.parseInt(txt_ID.getText()))){
                limparFormulario();
                listarProdutos();
            }
            else{
                JOptionPane.showMessageDialog(this, "Erro ao excluir produto!");
            }
        }
    }//GEN-LAST:event_btn_ExcluirActionPerformed

    private void btn_LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LimparActionPerformed
        limparFormulario();
    }//GEN-LAST:event_btn_LimparActionPerformed

    private void btn_BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_BuscarActionPerformed
        buscar();
    }//GEN-LAST:event_btn_BuscarActionPerformed

    private void txt_BuscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_BuscaActionPerformed
        buscar();
    }//GEN-LAST:event_txt_BuscaActionPerformed

    private void btn_ListarTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ListarTodosActionPerformed
        txt_Busca.setText("");
        listarProdutos();
    }//GEN-LAST:event_btn_ListarTodosActionPerformed

    private void tbl_ProdutosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_ProdutosMouseClicked
        int linha = tbl_Produtos.getSelectedRow();
        if(linha >= 0){
            carregarProduto((int) modelo.getValueAt(linha, 0));
        }
    }//GEN-LAST:event_tbl_ProdutosMouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        carregarCategorias();
    }//GEN-LAST:event_formWindowActivated

    // Variables declaration - do not modify//GEN-BEGIN:variables
    javax.swing.JPanel pnl_Topo;
    javax.swing.JPanel pnl_Dados;
    javax.swing.JLabel lbl_ID;
    javax.swing.JTextField txt_ID;
    javax.swing.JLabel lbl_Nome;
    javax.swing.JTextField txt_Nome;
    javax.swing.JLabel lbl_Preco;
    javax.swing.JTextField txt_Preco;
    javax.swing.JLabel lbl_Quantidade;
    javax.swing.JTextField txt_Quantidade;
    javax.swing.JLabel lbl_Categoria;
    javax.swing.JComboBox<Categoria> cmb_Categoria;
    javax.swing.JPanel pnl_Botoes;
    javax.swing.JButton btn_Salvar;
    javax.swing.JButton btn_Atualizar;
    javax.swing.JButton btn_Excluir;
    javax.swing.JButton btn_Limpar;
    javax.swing.JPanel pnl_Busca;
    javax.swing.JLabel lbl_BuscarPor;
    javax.swing.JComboBox<String> cmb_TipoBusca;
    javax.swing.JTextField txt_Busca;
    javax.swing.JButton btn_Buscar;
    javax.swing.JButton btn_ListarTodos;
    javax.swing.JScrollPane scr_Produtos;
    javax.swing.JTable tbl_Produtos;
    // End of variables declaration//GEN-END:variables
}
